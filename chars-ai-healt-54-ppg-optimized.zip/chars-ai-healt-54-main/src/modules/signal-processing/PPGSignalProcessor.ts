import { ProcessedSignal, ProcessingError, SignalProcessor as SignalProcessorInterface } from '../../types/signal';
import { BandpassFilter } from './BandpassFilter';
import { FrameProcessor } from './FrameProcessor';
import { SignalQualityAnalyzer } from './SignalQualityAnalyzer';

/**
 * PROCESADOR PPG - FLUJO LIMPIO
 * 
 * Frame → RGB → Canal Verde (mejor para PPG) → Filtro → Señal
 * 
 * IMPORTANTE: Usamos canal VERDE en lugar de rojo
 * El verde tiene mejor penetración en tejido y menos saturación
 */
export class PPGSignalProcessor implements SignalProcessorInterface {
  public isProcessing: boolean = false;
  
  private bandpassFilter: BandpassFilter;
  private frameProcessor: FrameProcessor;
  private qualityAnalyzer: SignalQualityAnalyzer;
  
  private readonly BUFFER_SIZE = 90;
  private rawBuffer: number[] = [];
  private filteredBuffer: number[] = [];
  
  private frameCount: number = 0;
  private lastLogTime: number = 0;
  
  constructor(
    public onSignalReady?: (signal: ProcessedSignal) => void,
    public onError?: (error: ProcessingError) => void
  ) {
    this.bandpassFilter = new BandpassFilter(30);
    this.frameProcessor = new FrameProcessor();
    this.qualityAnalyzer = new SignalQualityAnalyzer();
  }

  async initialize(): Promise<void> {
    this.rawBuffer = [];
    this.filteredBuffer = [];
    this.frameCount = 0;
    this.lastLogTime = 0;
    this.bandpassFilter.reset();
    this.frameProcessor.reset();
    this.qualityAnalyzer.reset();
  }

  start(): void {
    if (this.isProcessing) return;
    this.isProcessing = true;
    this.initialize();
    console.log('🚀 PPGSignalProcessor iniciado');
  }

  stop(): void {
    this.isProcessing = false;
    console.log('🛑 PPGSignalProcessor detenido');
  }

  async calibrate(): Promise<boolean> {
    return true;
  }

  /**
   * PROCESAR FRAME
   */
  processFrame(imageData: ImageData): void {
    if (!this.isProcessing || !this.onSignalReady) return;

    this.frameCount++;
    const timestamp = Date.now();
    
    // 1. Extraer RGB
    const frameData = this.frameProcessor.extractFrameData(imageData);
    const rawRed = frameData.rawRed ?? frameData.redValue;
    const rawGreen = frameData.rawGreen ?? 0;
    const rawBlue = frameData.rawBlue ?? 0;

    // 2) Señal PPG: usar VERDE como fuente principal (más estable en la mayoría de teléfonos)
    // El rojo lo guardamos para validación de dedo + SpO2 (si aplica)
    const isSaturated = !!frameData.isSaturated;
    const fingerPresent = !!frameData.fingerPresent;

    // Si por alguna razón green viene 0 (algunos devices raros / permisos), usar red de fallback.
    const signalSource = rawGreen > 0 ? rawGreen : rawRed;
    
    // 3. Invertir: más sangre = menos luz = valor más bajo
    // Invertimos para que los picos cardíacos sean positivos
    const inverted = 255 - signalSource;
    
    // 4. Guardar en buffer
    this.rawBuffer.push(inverted);
    if (this.rawBuffer.length > this.BUFFER_SIZE) {
      this.rawBuffer.shift();
    }
    
    // 5. Filtro pasabanda (0.3-5 Hz)
    const filtered = this.bandpassFilter.filter(inverted);
    
    this.filteredBuffer.push(filtered);
    if (this.filteredBuffer.length > this.BUFFER_SIZE) {
      this.filteredBuffer.shift();
    }
    
    // 6. Calidad de señal (dedo / PI / ruido)
    const rgbStats = this.frameProcessor.getRGBStats();
    const q = this.qualityAnalyzer.analyze({
      filteredValue: filtered,
      fingerPresent,
      isSaturated,
      rgb: { red: rawRed, green: rawGreen, blue: rawBlue },
      rgbStats,
    });

    // Log cada segundo
    const now = Date.now();
    if (now - this.lastLogTime >= 1000) {
      this.lastLogTime = now;
      const src = (signalSource === rawGreen && rawGreen > 0) ? 'G' : 'R';
      const fd = fingerPresent ? '✅' : '❌';
      console.log(`📷 PPG [${src}] ${fd} Q=${q.quality} PI=${q.perfusionIndex.toFixed(2)} | Raw=${signalSource.toFixed(0)} Inv=${inverted.toFixed(0)} Filt=${filtered.toFixed(2)}`);
    }
    
    // 7. Emitir
    const processedSignal: ProcessedSignal = {
      timestamp,
      rawValue: inverted,
      filteredValue: filtered,
      quality: q.quality,
      fingerDetected: fingerPresent,
      roi: frameData.roi ?? { x: 0, y: 0, width: imageData.width, height: imageData.height },
      perfusionIndex: q.perfusionIndex,
      rawGreen: frameData.rawGreen,
      diagnostics: {
        message: fingerPresent ? (isSaturated ? `SAT` : `OK`) : `NO_FINGER`,
        hasPulsatility: q.isSignalValid,
        pulsatilityValue: q.perfusionIndex
      }
    };

    this.onSignalReady(processedSignal);
  }
  
  private calculatePerfusionIndex(): number {
    const stats = this.frameProcessor.getRGBStats();
    if (stats.greenDC === 0) return 0;
    return (stats.greenAC / stats.greenDC) * 100;
  }

  reset(): void {
    this.rawBuffer = [];
    this.filteredBuffer = [];
    this.frameCount = 0;
    this.lastLogTime = 0;
    this.bandpassFilter.reset();
    this.frameProcessor.reset();
    this.qualityAnalyzer.reset();
  }

  getRGBStats() {
    return this.frameProcessor.getRGBStats();
  }

  getLastNSamples(n: number): number[] {
    return this.filteredBuffer.slice(-n);
  }
  
  getRawBuffer(): number[] {
    return [...this.rawBuffer];
  }
  
  getFilteredBuffer(): number[] {
    return [...this.filteredBuffer];
  }
}
