import { FrameData } from './types';
import { ProcessedSignal } from '../../types/signal';

/**
 * FrameProcessor - EXTRACCIÓN RGB CON ROI CENTRAL
 * 
 * Extrae el promedio de canales RGB de una región central del frame
 * Detecta saturación y presencia de dedo
 */
export class FrameProcessor {
  private redBuffer: number[] = [];
  private greenBuffer: number[] = [];
  private blueBuffer: number[] = [];
  private readonly BUFFER_SIZE = 90;
  
  private frameCount = 0;
  private lastLogTime = 0;
  
  /**
   * Extraer datos del frame
   * Usa ROI central del 50% para evitar bordes
   */
  extractFrameData(imageData: ImageData): FrameData {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    
    // ROI central - 50% del área (reduce ruido de bordes)
    const roiSize = Math.min(width, height) * 0.5;
    const startX = Math.floor((width - roiSize) / 2);
    const startY = Math.floor((height - roiSize) / 2);
    const endX = startX + Math.floor(roiSize);
    const endY = startY + Math.floor(roiSize);
    
    let redSum = 0;
    let greenSum = 0;
    let blueSum = 0;
    let count = 0;
    
    // Muestrear cada 2 píxeles
    for (let y = startY; y < endY; y += 2) {
      for (let x = startX; x < endX; x += 2) {
        const i = (y * width + x) * 4;
        redSum += data[i];
        greenSum += data[i + 1];
        blueSum += data[i + 2];
        count++;
      }
    }
    
    const rawRed = count > 0 ? redSum / count : 0;
    const rawGreen = count > 0 ? greenSum / count : 0;
    const rawBlue = count > 0 ? blueSum / count : 0;
    
    // Guardar en buffers
    this.redBuffer.push(rawRed);
    this.greenBuffer.push(rawGreen);
    this.blueBuffer.push(rawBlue);
    
    if (this.redBuffer.length > this.BUFFER_SIZE) {
      this.redBuffer.shift();
      this.greenBuffer.shift();
      this.blueBuffer.shift();
    }
    
    this.frameCount++;
    
    // Detectar condiciones
    const isSaturated = rawRed > 250;
    // Heurística simple y robusta:
    // - R relativamente alto (flash atravesando tejido)
    // - R no saturado
    // - R mayor que G (cuando el dedo cubre cámara con flash, el canal rojo suele dominar)
    const fingerPresent = rawRed > 80 && rawRed < 250 && (rawRed > rawGreen * 1.05);
    
    // Log cada segundo
    const now = Date.now();
    if (now - this.lastLogTime >= 1000) {
      this.lastLogTime = now;
      const status = isSaturated ? '⚠️ SATURADO' : (fingerPresent ? '✅ Dedo OK' : '❌ Sin dedo');
      console.log(`📷 RGB: R=${rawRed.toFixed(0)} G=${rawGreen.toFixed(0)} B=${rawBlue.toFixed(0)} | ${status}`);
    }
    
    return {
      redValue: rawRed,
      avgRed: rawRed,
      avgGreen: rawGreen,
      avgBlue: rawBlue,
      rawRed,
      rawGreen,
      rawBlue,
      fingerPresent,
      isSaturated,
      roi: { x: startX, y: startY, width: endX - startX, height: endY - startY },
      textureScore: 0,
      rToGRatio: rawGreen > 0 ? rawRed / rawGreen : 1,
      rToBRatio: rawBlue > 0 ? rawRed / rawBlue : 1
    };
  }
  
  getRGBStats(): { redAC: number; redDC: number; greenAC: number; greenDC: number; rgRatio: number } {
    if (this.redBuffer.length < 30) {
      return { redAC: 0, redDC: 0, greenAC: 0, greenDC: 0, rgRatio: 0 };
    }
    
    const recent = this.redBuffer.slice(-30);
    const recentG = this.greenBuffer.slice(-30);
    
    const redDC = recent.reduce((a, b) => a + b, 0) / recent.length;
    const greenDC = recentG.reduce((a, b) => a + b, 0) / recentG.length;
    const redAC = Math.max(...recent) - Math.min(...recent);
    const greenAC = Math.max(...recentG) - Math.min(...recentG);
    
    return { 
      redAC, 
      redDC, 
      greenAC, 
      greenDC, 
      rgRatio: greenDC > 0 ? redDC / greenDC : 0 
    };
  }
  
  detectROI(redValue: number, imageData: ImageData): ProcessedSignal['roi'] {
    return { x: 0, y: 0, width: imageData.width, height: imageData.height };
  }
  
  getIsSaturated(): boolean {
    if (this.redBuffer.length === 0) return false;
    return this.redBuffer[this.redBuffer.length - 1] > 250;
  }
  
  reset(): void {
    this.redBuffer = [];
    this.greenBuffer = [];
    this.blueBuffer = [];
    this.frameCount = 0;
    this.lastLogTime = 0;
  }
}
