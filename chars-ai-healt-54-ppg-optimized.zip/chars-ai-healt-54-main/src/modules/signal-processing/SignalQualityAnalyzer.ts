/**
 * ANALIZADOR DE CALIDAD DE SEÑAL PPG
 *
 * Objetivo: dar una "calidad" 0-100 estable para que el resto del sistema
 * pueda decidir si mostrar BPM/SpO2 o esperar.
 *
 * Importante:
 * - NO inventa datos.
 * - La calidad se basa en: dedo presente, perfusion index (AC/DC), y ruido.
 */

export interface SignalQualityResult {
  /** Índice de calidad global 0-100 */
  quality: number;

  /** Perfusion Index (%) - indica fuerza de pulso */
  perfusionIndex: number;

  /** Señal válida (dedo presente y PI mínimo) */
  isSignalValid: boolean;

  /** Razón de invalidez si aplica */
  invalidReason?: 'NO_SIGNAL' | 'LOW_PULSATILITY' | 'TOO_NOISY' | 'MOTION_ARTIFACT' | 'NO_FINGER';

  /** Métricas detalladas */
  metrics: {
    acAmplitude: number;
    dcLevel: number;
    snr: number;
    periodicity: number;
    stability: number;
    fingerConfidence: number;
  };
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function stddev(values: number[]): number {
  if (values.length < 2) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const v = values.reduce((acc, x) => acc + (x - mean) * (x - mean), 0) / values.length;
  return Math.sqrt(v);
}

export class SignalQualityAnalyzer {
  private readonly BUFFER_SIZE = 45;
  private filteredBuffer: number[] = [];

  // Suavizado para evitar saltos (siempre estable)
  private smoothedQuality = 0;
  private lastQuality: SignalQualityResult | null = null;

  analyze(params: {
    timestamp?: number;
    filteredValue: number;
    fingerPresent: boolean;
    isSaturated: boolean;
    rgb?: { red: number; green: number; blue: number };
    rgbStats?: { redAC: number; redDC: number; greenAC: number; greenDC: number; rgRatio: number };
  }): SignalQualityResult {
    const {
      filteredValue,
      fingerPresent,
      isSaturated,
      rgb,
      rgbStats,
    } = params;

    // Buffer de señal filtrada (para estimar ruido/estabilidad)
    this.filteredBuffer.push(filteredValue);
    while (this.filteredBuffer.length > this.BUFFER_SIZE) this.filteredBuffer.shift();

    const stats = rgbStats;
    const dc = stats?.greenDC ?? (rgb?.green ?? 0);
    const ac = stats?.greenAC ?? 0;
    const perfusionIndex = dc > 0 ? (ac / dc) * 100 : 0;

    // Métricas de estabilidad/ruido
    const noise = stddev(this.filteredBuffer.slice(-30));
    const signalAmp = Math.max(0.0001, ac);
    const snr = noise > 0 ? signalAmp / noise : signalAmp;
    const stability = clamp(1 - noise / 8, 0, 1);

    // Finger confidence (muy simple y transparente)
    const fingerConfidence = fingerPresent ? 1 : 0;

    // === Calidad objetivo ===
    let targetQuality = 0;
    let invalidReason: SignalQualityResult['invalidReason'] | undefined;

    if (!fingerPresent) {
      targetQuality = 5;
      invalidReason = 'NO_FINGER';
    } else if (dc < 30) {
      // Imagen muy oscura (flash apagado o cámara equivocada)
      targetQuality = 10;
      invalidReason = 'NO_SIGNAL';
    } else {
      // Escalado de calidad por PI
      // Nota: PI típico en smartphone puede ser bajo; no usamos umbrales agresivos.
      if (perfusionIndex < 0.08) {
        targetQuality = 35;
        invalidReason = 'LOW_PULSATILITY';
      } else if (perfusionIndex < 0.2) {
        targetQuality = 55;
      } else if (perfusionIndex < 0.6) {
        targetQuality = 72;
      } else {
        targetQuality = 86;
      }

      // Penalizaciones por saturación y ruido
      if (isSaturated || (rgb?.red ?? 0) > 250 || (rgb?.green ?? 0) > 250) {
        targetQuality -= 10;
      }
      if (noise > 10) {
        targetQuality -= 25;
        invalidReason = 'TOO_NOISY';
      } else if (noise > 6) {
        targetQuality -= 12;
      }

      // Limitar
      targetQuality = clamp(targetQuality, 0, 100);
    }

    // Suavizado
    const alpha = 0.15;
    if (this.smoothedQuality === 0) this.smoothedQuality = targetQuality;
    this.smoothedQuality = alpha * targetQuality + (1 - alpha) * this.smoothedQuality;

    const quality = Math.round(clamp(this.smoothedQuality, 0, 100));
    const isSignalValid = fingerPresent && quality >= 45;

    const result: SignalQualityResult = {
      quality,
      perfusionIndex: Number.isFinite(perfusionIndex) ? perfusionIndex : 0,
      isSignalValid,
      ...(isSignalValid ? {} : { invalidReason }),
      metrics: {
        acAmplitude: ac,
        dcLevel: dc,
        snr,
        periodicity: 0.8, // placeholder simple (sin FFT para no gastar CPU)
        stability,
        fingerConfidence,
      },
    };

    this.lastQuality = result;
    return result;
  }

  getLastQuality(): SignalQualityResult | null {
    return this.lastQuality;
  }

  reset(): void {
    this.filteredBuffer = [];
    this.smoothedQuality = 0;
    this.lastQuality = null;
  }
}
