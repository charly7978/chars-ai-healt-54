
import { useToast, toast } from "@/hooks/use-toast";

// Reexport for consistent usage across the app
export { useToast, toast };
